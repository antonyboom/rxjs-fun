import {
  ChangeDetectionStrategy,
  Component,
  Output,
  Input,
  EventEmitter
} from '@angular/core';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-complete-all',
  styleUrls: ['./complete-all.component.scss',],
  templateUrl: './complete-all.component.html',
})
export class CompleteAllComponent {

  @Output() toggleAllCompletedEvent: EventEmitter<boolean> = new EventEmitter<boolean>()

  @Input() multipleTodosExist = false;
  @Input() activeListLength: number = null;

  toggleCompleteAll(toggle: boolean): void {
    this.toggleAllCompletedEvent.emit(toggle)
  }

}
