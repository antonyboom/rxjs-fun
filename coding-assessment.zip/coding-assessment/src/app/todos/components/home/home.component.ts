import {Component, OnInit} from '@angular/core';
import {combineLatest, map, Observable} from 'rxjs';
import {ITodo} from '@app/todos/interfaces';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {Router} from '@angular/router';
import {TodosService} from '@app/todos/services/todos.service';
import {FILTER_MODES} from '@app/todos/constants/filter-modes';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  public multipleTodosExist$: Observable<boolean>;
  public todoList$: Observable<ITodo[]>;
  public activeListLength$: Observable<number>;
  public completedListLength$: Observable<number>;
  public currentFilter$: Observable<FILTER_MODES>


  public todoForm: FormGroup = this.fb.group({
    newTask: new FormControl('', [])
  })

  public FILTER_MODES = {
    all: FILTER_MODES.all,
    active: FILTER_MODES.active,
    completed: FILTER_MODES.completed
  };

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private todosService: TodosService
  ) {
    this.multipleTodosExist$ = this.todosService.allTodos$.pipe(map(todos => todos && todos.length >= 1));
    this.activeListLength$ = this.todosService.activeTodosLength$;
    this.completedListLength$ = this.todosService.completedTodosLength$;
    this.currentFilter$ = this.todosService.currentFilter$;
    /* no particular reason why it is here and not taken from selector, besides we don't use entity and rxjs demoing */
    this.todoList$ = combineLatest([this.todosService.allTodos$, this.todosService.currentFilter$])
      .pipe(
        map(([todos, mode]) => {
          return todos.filter(item => {
            switch (mode) {
              case FILTER_MODES.active:
                return !item.completed
              case FILTER_MODES.completed:
                return item.completed
              default:
                return item
            }
          })
        })
      )
  }

  ngOnInit() {
    /* on init reading local storage and set values to state */
    const storage = JSON.parse(localStorage.getItem('todos')) || [];
    if (storage.length) {
      this.todosService.setTodos(storage);
    }
    const url = this.router.url.replace('/', '');
    /* reading url to apply default filter on refresh */
    switch (true) {
      case url === FILTER_MODES.completed.toLowerCase():
        this.todosService.changeFilterMode(FILTER_MODES.completed);
        break;
      case url === FILTER_MODES.active.toLowerCase():
        this.todosService.changeFilterMode(FILTER_MODES.active);
    }
  }

  public toggleAllCompleted(toggle: boolean) {
    this.todosService.toggleAllCompleted(toggle);
  }

  public onSubmit(): void {
    const task: string = this.todoForm.get('newTask').value;
    /* prevent empty values */
    if (!!task) {
      this.todosService.addTodo(task);
      this.todoForm.reset();
    }
  }

  public taskChecked(event: number): void {
    this.todosService.toggleComplete(event);
  }

  public taskDeleted(event: number): void {
    this.todosService.removeTodo(event);
  }

  public taskModified(event: { text: string, index: number }) {
    this.todosService.updateTodo(event.index, event.text)
  }

  public clearCompleted(): void {
    this.todosService.clearCompleted();
  }

  public changeFilter(mode: FILTER_MODES): void {
    this.todosService.changeFilterMode(mode)
  }


}
