import {Component, EventEmitter, Input, Output} from '@angular/core';
import {ITodo} from '@app/todos/interfaces';
import {FILTER_MODES} from '@app/todos/constants/filter-modes';

@Component({
  selector: 'app-todos-list',
  styleUrls: ['./todo-list.component.scss',],
  templateUrl: './todo-list.component.html',
})
export class TodosListComponent {

  @Input() todoList: ITodo[];
  @Input() currentFilter: FILTER_MODES;


  @Output() taskCheckedEvent: EventEmitter<number> = new EventEmitter<number>();
  @Output() taskDeletedEvent: EventEmitter<number> = new EventEmitter<number>();
  @Output() taskModifiedEvent: EventEmitter<{ text: string; index: number }> = new EventEmitter<{ text: string; index: number }>();

  modelValue = '';
  selectedIndex: number = null;

  public taskChecked(index: number): void {
    this.taskCheckedEvent.emit(index);
  }

  public taskDeleted(index: number): void {
    this.taskDeletedEvent.emit(index);
  }

  public onSubmit(text: string, index: number): void {
    this.selectedIndex = null;
    this.taskModifiedEvent.emit({text, index})
  }

  public onDbClick(text: string, index: number): void {
    this.selectedIndex = this.selectedIndex === index ? null : index;
    this.modelValue = text;
  }
}
