export enum FILTER_MODES {all = 'All', active = 'Active', completed = 'Completed'}

