// tslint:disable-next-line:no-shadowed-variable
export interface ITodo {
  text: string;
  completed?: boolean;
}
