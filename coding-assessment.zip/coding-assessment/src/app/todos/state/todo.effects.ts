import {Injectable} from '@angular/core';
import {Actions, createEffect} from '@ngrx/effects';
import {map, switchMap, tap} from 'rxjs';
import {TodosService} from '@app/todos/services/todos.service';

@Injectable({
  providedIn: 'root'
})
export class TodoEffects {

  setStorage$ = createEffect(() =>
      this.actions$.pipe(
        switchMap((action) => this.todosService.allTodos$.pipe(map(todos => {
          return {
            action, todos
          }
        }))),
        tap(stream => {
          /* skip on load to avoid storage reset */
          /* ugly but works for simple app */
          if (!stream.action.type.includes('init')) {
            localStorage.setItem('todos', JSON.stringify(stream.todos))
          }
        })
      ),
    {dispatch: false});

  constructor(
    private actions$: Actions,
    private todosService: TodosService
  ) {
  }

}
