// tslint:disable-next-line:no-shadowed-variable
import {Action, createReducer, on} from '@ngrx/store';
// tslint:disable-next-line:no-shadowed-variable
import * as TodoActions from './todo.actions';

// tslint:disable-next-line:no-shadowed-variable
import {FILTER_MODES} from './../constants/filter-modes';
// tslint:disable-next-line:no-shadowed-variable
import {ITodo} from '../interfaces/ITodo';

// tslint:disable-next-line:no-shadowed-variable
export interface ITodosState {
  filterMode?: FILTER_MODES;
  todos?: ITodo[];
}

export const initialState: ITodosState = {
  filterMode: FILTER_MODES.all,
  todos: [],
};

export function todosReducer(state: ITodosState, action: Action) {
  return createReducer(
    initialState,
    on(TodoActions.setTodos, (existingState, {tasks}) => {
      return {
        ...existingState,
        todos: [...tasks],
      };
    }),
    on(TodoActions.addTodo, (existingState, {text}) => ({
      ...existingState,
      todos: [{text, completed: false}, ...existingState.todos],
    })),
    on(TodoActions.updateTodo, (existingState, {index, text}) => {
      const updatedTodos = [...existingState.todos];
      return {
        ...existingState,
        todos: updatedTodos.map((item, i) => {
          if (i === index) {
            return {...item, text}
          }
          return item;
        }),
      };
    }),
    on(TodoActions.removeTodo, (existingState, {index}) => {
      const updatedTodos = [...existingState.todos];
      updatedTodos.splice(index, 1);

      return {
        ...existingState,
        todos: updatedTodos,
      };
    }),
    on(TodoActions.toggleCompleted, (existingState, {index}) => {
      const updatedTodos = [...existingState.todos];
      return {
        ...existingState,
        todos: [...updatedTodos.map((item, idx) => {
          if (idx === index) {
            return {...item, completed: !item.completed};
          }
          return item
        })],
      };
    }), on(TodoActions.toggleAllCompleted, (existingState, {toggle}) => {
      const updatedTodos = [...existingState.todos];
      return {
        ...existingState,
        todos: [...updatedTodos.map((item, idx) => {
          return {...item, completed: !toggle}
        })],
      };
    }),
    on(TodoActions.changeFilterMode, (existingState, {mode}) => {
      return {
        ...existingState,
        filterMode: mode,
      }
    }),
    on(TodoActions.clearCompleted, (existingState) => ({
      ...existingState,
      todos: [...existingState.todos.filter(todo => !todo.completed)],
    })),
  )(state, action);
}

export const filterMode = (state: ITodosState) => state.filterMode;
export const todos = (state: ITodosState) => state.todos;
