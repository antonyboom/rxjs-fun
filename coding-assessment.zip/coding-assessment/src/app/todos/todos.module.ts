import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {NgModule} from '@angular/core';
import {StoreModule} from '@ngrx/store';

import {CompleteAllComponent} from './components/complete-all/complete-all.component';
import {TodosListComponent} from './components/todo-list/todo-list.component';
import {TodosService} from './services/todos.service';
import {todosReducer} from './state/todos.reducer';
import {HomeComponent} from './components/home/home.component';
import {BrowserModule} from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import {RouterModule} from '@angular/router';
import {TodosRoutingModule} from '@app/todos/todos-routing.module';
import {EffectsModule} from '@ngrx/effects';
import {TodoEffects} from '@app/todos/state/todo.effects';

const DECLARATIONS = [
  CompleteAllComponent,
  TodosListComponent,
]

@NgModule({
  declarations: [
    ...DECLARATIONS,
    HomeComponent,
  ],
  exports: [
    ...DECLARATIONS,
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    EffectsModule.forFeature([TodoEffects]),
    StoreModule.forFeature('todos', todosReducer),
    RouterModule,
    TodosRoutingModule
  ],
  providers: [
    TodosService
  ],
})
export class TodosModule {
}
